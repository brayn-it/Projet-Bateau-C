#include "line.hpp"


Line::Line(){
    dimension = sf::Vector2f(10.f,700.f);
    position = sf::Vector2f(50.f,50.f);
    color = sf::Color::Green;
    line.setSize(dimension);
    line.setPosition(position);
    line.setFillColor(color);
}


Line::Line(sf::Vector2f d, sf::Vector2f p,sf::Color c){
    position = p;
    dimension = d;
    color = c;
    line.setSize(dimension);
    line.setPosition(position);
    line.setFillColor(color);
}


Line::~Line(){}


sf::Vector2f& Line::getPosition(){
    return position;
}


sf::Vector2f& Line::getDimention(){
    return dimension;
}


void Line::draw(sf::RenderWindow &window) const{
    window.draw(line);
}
