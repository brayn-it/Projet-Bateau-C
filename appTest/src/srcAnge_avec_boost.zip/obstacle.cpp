#include "obstacle.hpp"


Obstacle::Obstacle(){
    dimension = sf::Vector2f(10.f,700.f);
    position = sf::Vector2f(50.f,50.f);
    color = sf::Color::Black;
    shape.setSize(dimension);
    shape.setPosition(position);
    shape.setFillColor(color);
}


Obstacle::Obstacle(sf::Vector2f d, sf::Vector2f p){
    position = p;
    dimension = d;
    color = sf::Color::Black;
    shape.setSize(dimension);
    shape.setPosition(position);
    shape.setFillColor(color);
}


Obstacle::~Obstacle(){}


sf::Vector2f& Obstacle::getPosition(){
    return position;
}


sf::Vector2f& Obstacle::getDimention(){
    return dimension;
}


void Obstacle::draw(sf::RenderWindow &window) const{
    window.draw(shape);
}
