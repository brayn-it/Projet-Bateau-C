#ifndef RACE_HPP
#define RACE_HPP

#include <SFML/Graphics.hpp>
// #include <SFML/Audio.hpp>

#include "physics/dynamicModel.h"
#include "physics/physicsEngine.h"
#include "physics/common.h"
#include "physics/platform_core.h"

#include <filesystem>
#include <iostream>
#include <vector>
using namespace std;

#include "line.hpp"
#include "obstacle.hpp"
#include "boost.hpp"
#include "boat.hpp"
#include "menu.hpp"
#include "starting_lights.hpp"
#include "resultdashboard.hpp"


enum class RaceState{Starting, Running, Finished};

class Race{
    private:
        sim::physics::PhysicsEngine engine; //Moteur physique de la course
        double dt;

        sim::physics::DynamicModel model; 

        sf::RenderWindow& window;

        sf::Clock clock;
        float startTime; // apres depart de course
        float endTime;   // ligne d'arrivee franchie
        sf::Int64 time_loop; // temps d'exécution des boucles

        Line startline;
        Line finishline;

        vector<Obstacle> obstacles;
        vector<Boost> boosts;
        vector<Boat> boats;

        int mode = 1; //1 joueur ou 2
        RaceState state = RaceState::Starting;
        bool active_command = false; // savoir si les commandes sont actives

        //Feu depart
        StartingLights startingLights;

        // Sons
        // sf::SoundBuffer endingSoundbuffer;
        // sf::Sound endingSound;

        //ResultDashboard
        ResultDashboard result;

        void command_control();

        sim::common::Vector2 inObstacle(Boat&, Obstacle&);
        sim::common::Vector2 inBoost(Boat&, Boost&);
        sim::common::Vector2 intersection_seg(sim::common::Vector2, sim::common::Vector2, sim::common::Vector2, sim::common::Vector2);

        void SetPos(Boat&, Obstacle&, sim::common::Vector2&);
        sf::Color randomColor();

        void creerObstacle1();
        void creerObstacle2();
        void creerBoost1();
        void creerBoost2();
        void createBoat();
        void createObstacle(sf::Vector2f dim, sf::Vector2f pos);
        void createBoost(sf::Vector2f dim, sf::Vector2f pos);

        void collision_Ob(Boat&);
        void collision_Bo(Boat&);

        void updateRaceState();

        filesystem::path getAssetPath(const std::string&);
    
    public:
        Race(sf::RenderWindow&, sf::Clock&);
        ~Race();

        void init(int);
        void run();

        void pollEvents();
        void update();
        void render();
};

#endif