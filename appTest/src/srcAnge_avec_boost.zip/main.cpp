#include "game.hpp"

int main(){	
	Game *game = new Game();
	game->running();
	delete game;
	return 0;
}
