#ifndef GAME_HPP
#define GAME_HPP

#include <SFML/Graphics.hpp>

#include "physics/dynamicModel.h"
#include "physics/physicsEngine.h"

#include <iostream>
#include <filesystem>
#include <string>
#include <vector>
using namespace std;

#include "line.hpp"
#include "obstacle.hpp"
#include "boost.hpp"
#include "boat.hpp"
#include "menu.hpp"
#include "starting_lights.hpp"
#include "race.hpp"
#include "dashboard.hpp"

enum class GameState {Menu, Play};

class Game{
    private:
        sim::physics::PhysicsEngine engine; //Moteur physique du jeu
        sf::Clock clock;
        double dt;

        //Largeur et Hauteur de la fenetre du jeu == type unsigned int requis pour param video
        unsigned int width;
        unsigned int height;
        string title;

        //Video mode
        sf::VideoMode vm;
        sf::RenderWindow window;

        //Fenetre de menu
        Menu menu;
        GameState state;
        int mode=1;
        sf::Font font;
        
        Race race;

        void pollEvents();
        void rendering();
        filesystem::path getAssetPath(const std::string&);
    
    public:
        Game();
        ~Game();

        void running();
};

#endif