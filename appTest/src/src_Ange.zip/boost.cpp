#include "boost.hpp"


Boost::Boost(){
    dimension = sf::Vector2f(10.f,700.f);
    position = sf::Vector2f(50.f,50.f);
    color = sf::Color::Yellow;
    shape.setSize(dimension);
    shape.setPosition(position);
    shape.setFillColor(color);
}


Boost::Boost(sf::Vector2f d, sf::Vector2f p){
    position = p;
    dimension = d;
    color = sf::Color::Yellow;
    shape.setSize(dimension);
    shape.setPosition(position);
    shape.setFillColor(color);
}


Boost::~Boost(){}


sf::Vector2f& Boost::getPosition(){
    return position;
}


sf::Vector2f& Boost::getDimention(){
    return dimension;
}


void Boost::draw(sf::RenderWindow &window) const{
    window.draw(shape);
}
