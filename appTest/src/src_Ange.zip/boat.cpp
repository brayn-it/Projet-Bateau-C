#include "boat.hpp"
#include <cmath>
#include <iostream>
using namespace std;


filesystem::path Boat::getAssetPath(const std::string& relativePath){
    // __FILE__ donne le chemin du fichier source courant
    filesystem::path sourceDir = filesystem::path(__FILE__).parent_path();
    
    // Remonte jusqu’au dossier du projet (ex: depuis src/jeu.cpp → ../../assets/...)
    filesystem::path assetDir = sourceDir / ".." / "assets";

    // Normalise le chemin
    assetDir = filesystem::canonical(assetDir);

    return assetDir / relativePath;
}


Boat::Boat(sim::physics::RigidBody* pbody, sf::Color pcolor){
    factor.x = 0.1;
    factor.y = 0.1;
	body = pbody;
    body->setPosition(84*factor.x, 70*factor.y);

    // Initialisation des points du bateau par rapport au barycentre (distance)
    l_point[0] = sf::Vector2f(-34.f, -20.f);
    l_point[1] = sf::Vector2f(16.f, -20.f);
    l_point[2] = sf::Vector2f(36.f, 0.f);
    l_point[3] = sf::Vector2f(16.f, 20.f);
    l_point[4] = sf::Vector2f(-34.f, 20.f);

	// Créer les formes du bateau
	shape.setPointCount(5);
    for (int i=0; i<5; i++){
        shape.setPoint(i, l_point[i]);
    }
	shape.setFillColor(pcolor);

    // Audio Bateau
    engineSoundBuffer.loadFromFile(getAssetPath("audio/boatengine.mp3").string());
    engineSound.setBuffer(engineSoundBuffer);
    engineSound.setLoop(true);
}


sf::ConvexShape& Boat::getShape(){
    return shape;
}


sim::physics::RigidBody* Boat::getBody(){
    return body;
}


sf::Vector2f& Boat::getPoint(int id){
    return l_point[id];
}


sim::common::Vector2& Boat::getFactor(){
    return factor;
}


Dashboard Boat::getDashboard(){
    return dashboard;
}


void Boat::setDashboardPosition(const sf::Vector2f& pos){
    dashboard = Dashboard(pos);
}


void Boat::setDashboardPlayerText(int j){
    dashboard.configPlayerText(j);
}


void Boat::setBoatPosition(const sf::Vector2f& pos){
    body->setPosition(pos.x*getFactor().x,pos.y*getFactor().y);
    update_point();
}


void Boat::Move_X(sim::physics::DynamicModel model, double rpm, double angle, double rho){
    sim::common::ForceTorque2D force = model.computeActuators(*body, rpm, angle, rho);
    body->addForce(force);
}


void Boat::Move_Y(sim::physics::DynamicModel model, double rpm, double angle, double rho){
    sim::common::ForceTorque2D force = model.computeActuators(*body, rpm, angle, rho);
    body->addForce(force);
}


void Boat::update(sim::physics::DynamicModel model){
    sim::common::ForceTorque2D force = model.computeDamping(*body, 1026);
    if (body->getState().velocity_body.x < 0){
        force.y = -15000 * body->getState().velocity_body.y;
    }
    body->addForce(force);
    update_point();
    updateDashboard();
}


void Boat::update_point(){
    sim::common::Vector2 pos = body->getState().position;
    float angle = body->getState().yaw * sim::common::RAD_TO_DEG;
    sim::common::Vector2 pos_screen = sim::common::worldToScreen(pos, factor);
    shape.setPosition(pos_screen.x, pos_screen.y);
    shape.setRotation(angle);
}


void Boat::updateDashboard(){
    float speed = this->getBody()->getState().velocity_body.x; //Vitesse
    float yawDeg = this->getBody()->getState().yaw * sim::common::RAD_TO_DEG;
    float rdot = this->getBody()->getState().r;
    dashboard.update(speed, yawDeg, rdot);
}


sim::common::Vector2 Boat::point_rotation(const sf::Vector2f& p, float angle) const{
    float cs = cos(angle);
    float sn = sin(angle);
    return sim::common::Vector2(p.x*cs - p.y*sn, p.x*sn + p.y*cs);
}


void Boat::draw(sf::RenderWindow &window){
    window.draw(shape);
    dashboard.draw(window);
}
