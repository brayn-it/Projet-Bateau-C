#include "game.hpp"


void Game::pollEvents(){
    sf::Event event;
    //event processing

    while (window.pollEvent(event))
    {
        //Close window
        if(event.type == sf::Event::Closed)
            window.close();
        
        //EVENT DE CHAQUE FENETRE
        if(state == GameState::Menu){
            menu.pollEvents(event);
            //Apres appui du bouton start
            if(menu.isReadyToStart()){
                mode = menu.getSelectedPlayer();
                race.init(mode);
                state = GameState::Play;
            }
        }
        else if(state == GameState::Play){
            race.pollEvents();
        }
    }
}


void Game::rendering(){
    window.clear(sf::Color::Blue);
    race.render();
}


filesystem::path Game::getAssetPath(const std::string& relativePath){
    // __FILE__ donne le chemin du fichier source courant
    filesystem::path sourceDir = filesystem::path(__FILE__).parent_path();
    
    // Remonte jusqu’au dossier du projet (ex: depuis src/jeu.cpp → ../../assets/...)
    filesystem::path assetDir = sourceDir / ".." / "assets";

    // Normalise le chemin
    assetDir = filesystem::canonical(assetDir);

    return assetDir / relativePath;
}


Game::Game():
    width(1280),
    height(720),
    vm(sf::VideoMode(width,height)),
    window(vm,"BOAT RACE"),
    menu(window),
    state(GameState::Menu),
    race(window,clock){
    window.setFramerateLimit(60);
    dt = 0.01;
    clock = sf::Clock();
}


Game::~Game(){}


void Game::running(){
    while(window.isOpen()){
        if(state == GameState::Menu){
            pollEvents();
            menu.update();
            menu.render();
        }
        else if(state == GameState::Play){
            race.run();
        }
        window.display();
    }
}
