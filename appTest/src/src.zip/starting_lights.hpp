#ifndef STARTINGLIGHTS_HPP
#define STARTINGLIGHTS_HPP

#include <SFML/Graphics.hpp>
// #include <SFML/Audio.hpp>

#include <iostream>
#include <filesystem>
#include <string>
using namespace std;

enum class LightState {Red, Yellow, Green};

class StartingLights{
    private:
        LightState state;
        // sf::SoundBuffer buffer;
        // sf::Sound sound;
        //cercle rouge, jaune, vert
        sf::CircleShape cercle;
        //rayon du cercle
        float rayon=25;
        sf::Clock& clock;
        bool active=false;
        filesystem::path getAssetPath(const std::string&);
    public:
        StartingLights(sf::Clock&);
        StartingLights(float, sf::Clock&);
        void start();
        void update();
        void draw(sf::RenderWindow &);

};

#endif