#ifndef LINE_HPP
#define LINE_HPP

#include <SFML/Graphics.hpp>

#include "physics/dynamicModel.h"
#include "physics/physicsEngine.h"

#include <iostream>
#include <string>
using namespace std;

class Line{
    private:
        sf::RectangleShape line;
        sf::Vector2f position;
        sf::Vector2f dimension;
        sf::Color color;

    public:
        Line();
        Line(sf::Vector2f,sf::Vector2f,sf::Color);
        ~Line();

        sf::Vector2f& getPosition();
        sf::Vector2f& getDimention();
        
        void draw(sf::RenderWindow &) const;
};

#endif