#include "race.hpp"


void Race::command_control(){
    //Commande bateau 1
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Z)) boats[0].Move_X(model, 6000, 0, 1026);
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Q)) boats[0].Move_Y(model, 3500, 90, 1026);
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S)) boats[0].Move_X(model, 6000, 180, 1026);
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D)) boats[0].Move_Y(model, 3500, -90, 1026);

    //Commande Bateau 2
    if (boats.size() >= 2){
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up)) boats[1].Move_X(model, 6000, 0, 1026);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left)) boats[1].Move_Y(model, 3500, 90, 1026);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Down)) boats[1].Move_X(model, 6000, 180, 1026);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right)) boats[1].Move_Y(model, 3500, -90, 1026);
    }
}


sim::common::Vector2 Race::inObstacle(Boat& b, Obstacle& O){
    int i = 0;
    int nb_boat_point = b.getShape().getPointCount();
    float angle = b.getBody()->getState().yaw;
    sim::common::Vector2 Point_inter = sim::common::Vector2 (-1, -1);
    while (i<nb_boat_point && Point_inter.x == -1 && Point_inter.y == -1){
        sim::common::Vector2 tmp = b.point_rotation(b.getPoint(i), angle);
        sim::common::Vector2 P1_Boat = sim::common::Vector2 (b.getShape().getPosition().x + tmp.x, b.getShape().getPosition().y + tmp.y);
        tmp = b.point_rotation(b.getPoint((i+1) % nb_boat_point), angle);
        sim::common::Vector2 P2_Boat = sim::common::Vector2 (b.getShape().getPosition().x + tmp.x, b.getShape().getPosition().y + tmp.y);
        sim::common::Vector2 P1_Ob = sim::common::Vector2 (O.getPosition().x, O.getPosition().y);
        sim::common::Vector2 P2_Ob = sim::common::Vector2 (O.getPosition().x + O.getDimention().x, O.getPosition().y);
        sim::common::Vector2 P3_Ob = sim::common::Vector2 (O.getPosition().x + O.getDimention().x, O.getPosition().y + O.getDimention().y);
        sim::common::Vector2 P4_Ob = sim::common::Vector2 (O.getPosition().x, O.getPosition().y + O.getDimention().y);
        tmp = intersection_seg(P1_Boat, P2_Boat, P1_Ob, P2_Ob);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        tmp = intersection_seg(P1_Boat, P2_Boat, P2_Ob, P3_Ob);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        tmp = intersection_seg(P1_Boat, P2_Boat, P3_Ob, P4_Ob);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        tmp = intersection_seg(P1_Boat, P2_Boat, P4_Ob, P1_Ob);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        i++;
    }
    return (Point_inter);
}


sim::common::Vector2 Race::inBoost(Boat& b, Boost& B){
    int i = 0;
    int nb_boat_point = b.getShape().getPointCount();
    float angle = b.getBody()->getState().yaw;
    sim::common::Vector2 Point_inter = sim::common::Vector2 (-1, -1);
    while (i<nb_boat_point && Point_inter.x == -1 && Point_inter.y == -1){
        sim::common::Vector2 tmp = b.point_rotation(b.getPoint(i), angle);
        sim::common::Vector2 P1_Boat = sim::common::Vector2 (b.getShape().getPosition().x + tmp.x, b.getShape().getPosition().y + tmp.y);
        tmp = b.point_rotation(b.getPoint((i+1) % nb_boat_point), angle);
        sim::common::Vector2 P2_Boat = sim::common::Vector2 (b.getShape().getPosition().x + tmp.x, b.getShape().getPosition().y + tmp.y);
        sim::common::Vector2 P1_Bo = sim::common::Vector2 (B.getPosition().x, B.getPosition().y);
        sim::common::Vector2 P2_Bo = sim::common::Vector2 (B.getPosition().x + B.getDimention().x, B.getPosition().y);
        sim::common::Vector2 P3_Bo = sim::common::Vector2 (B.getPosition().x + B.getDimention().x, B.getPosition().y + B.getDimention().y);
        sim::common::Vector2 P4_Bo = sim::common::Vector2 (B.getPosition().x, B.getPosition().y + B.getDimention().y);
        tmp = intersection_seg(P1_Boat, P2_Boat, P1_Bo, P2_Bo);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        tmp = intersection_seg(P1_Boat, P2_Boat, P2_Bo, P3_Bo);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        tmp = intersection_seg(P1_Boat, P2_Boat, P3_Bo, P4_Bo);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        tmp = intersection_seg(P1_Boat, P2_Boat, P4_Bo, P1_Bo);
        if (tmp.x != -1 && tmp.y != -1) Point_inter = tmp;
        i++;
    }
    return (Point_inter);
}


sim::common::Vector2 Race::intersection_seg(sim::common::Vector2 A, sim::common::Vector2 B, sim::common::Vector2 C, sim::common::Vector2 D){
    // Renvoie le point d'intersection des segments AB et CD s'il existe sinon None
    float det = (B.x - A.x) * (C.y - D.y) - (C.x - D.x) * (B.y - A.y); // determinant de Cramer de l'equation

    if (det != 0){ // non colineaire
        float t1 = ((C.x - A.x) * (C.y - D.y) - (C.x - D.x) * (C.y - A.y)) / det;
        float t2 = ((B.x - A.x) * (C.y - A.y) - (C.x - A.x) * (B.y - A.y)) / det;

        if (!(t1>1 || t1<0 || t2>1 || t2<0)){ // Point d'intersection
            if (t1 == 0) return A;
            else if (t1 == 1) return B;
            else if (t2 == 0) return C;
            else if (t2 == 1) return D;
            else return sim::common::Vector2 (A.x + t1*(B.x-A.x), A.y + t1*(B.y-A.y));
        }
    }
    return sim::common::Vector2 (-1, -1);
}


void Race::SetPos(Boat& b, Obstacle& O, sim::common::Vector2& P){
    double left = O.getPosition().x;
    double up = O.getPosition().y;
    double right = O.getPosition().x + O.getDimention().x;
    double down = O.getPosition().y + O.getDimention().y;
    // 0.00001 -> marge d'erreur : travail en double
    if (P.x - left < 0.00001) b.getBody()->setPosition(b.getBody()->getState().position.x - 1 * b.getFactor().x, b.getBody()->getState().position.y);
    else if (P.y - up < 0.00001) b.getBody()->setPosition(b.getBody()->getState().position.x, b.getBody()->getState().position.y - 1 * b.getFactor().y);
    else if (right - P.x < 0.00001) b.getBody()->setPosition(b.getBody()->getState().position.x + 1 * b.getFactor().x, b.getBody()->getState().position.y);
    else if (down - P.y < 0.00001) b.getBody()->setPosition(b.getBody()->getState().position.x, b.getBody()->getState().position.y + 1 * b.getFactor().y);
}


sf::Color Race::randomColor(){
    //Renvoie une couleur aleatoire
    int r = rand()%255;
    int g = rand()%255;
    int b = rand()%255;
    return sf::Color(r,g,b,255);
}


void Race::creerObstacle1(){
    //Obstacles pour 1 joueur
    sf::Vector2f dim(25, 50);
    float x = 300;
    float y;
    for(int i=0;i<7;i++){
        y = rand()%720*1.0;
        Obstacle obs(dim,{x,y});
        obstacles.push_back(obs);
        x += 100;
    }
}


void Race::creerObstacle2(){
    //Obstacles pour 2 joueurs
    sf::Vector2f dim(25,50);
    float x = 300;
    float y;
    for(int i=0;i<7;i++){
        y = rand()%250*1.0;
        Obstacle obs(dim,{x,y});
        obstacles.push_back(obs);
        x += 100;
    }
    x=300;
    for(int i=0; i<7; i++){
        y = rand()%250*1.0+250;
        Obstacle obs(dim,{x,y});
        obstacles.push_back(obs);
        x=x+100;
    }
}


void Race::createBoat(){
    for(int i=0;i<2;i++){
        sim::physics::RigidBody* body = engine.createGenericBoat();
        Boat B(body, randomColor());
        boats.push_back(B);
    }
}


void Race::createObstacle(sf::Vector2f dim, sf::Vector2f pos){
    Obstacle ob(dim,pos);
    obstacles.push_back(ob);
}


void Race::createBoost(sf::Vector2f dim, sf::Vector2f pos){
    Boost b(dim,pos);
    boosts.push_back(b);
}


void Race::collision_Ob(Boat& b){
    //Gere collision avec obstacles
    int i = 0;
    sim::common::Vector2 P_inter = sim::common::Vector2 (-1, -1);
    while (i<obstacles.size() && P_inter.x == -1 && P_inter.y == -1){
        P_inter = inObstacle(b, obstacles[i]);
        i++;
    }
    if (P_inter.x != -1 && P_inter.y != -1){
        SetPos(b, obstacles[i-1], P_inter);
        b.getBody()->setVelocity_body(0, 0);
    }
}


void Race::collision_Bo(Boat& b){
    int i = 0;
    sim::common::Vector2 P_inter = sim::common::Vector2 (-1, -1);
    while (i<boosts.size() && P_inter.x == -1 && P_inter.y == -1){
        P_inter = inBoost(b, boosts[i]);
        i++;
    }
    if (P_inter.x != -1 && P_inter.y != -1){
        if (b.getBody()->getState().velocity_body.x > 0){
            b.getBody()->setVelocity_body(30, b.getBody()->getState().velocity_body.y);
        }
    }
}


void Race::updateRaceState(){
    float t = clock.getElapsedTime().asSeconds();
    //Debut de la course en activant les commandes
    if(state == RaceState::Starting && t>=4.5f){
        state = RaceState::Running;
        active_command = true;
        //DEBUT DE TIME
        startTime = clock.getElapsedTime().asSeconds();
    }

    if(state == RaceState::Running){
        //SELON LE MODE JOUEURS
        //Desactive les controles quand un des joueur a franchi la ligne
        //Affiche les resultats
        if(mode==1){
            float xBoat = boats[0].getBody()->getState().position.x/boats[0].getFactor().x; //Division par le facteur pour avoir la pos sur ecran
            if(xBoat >= finishline.getPosition().x){
                // endingSound.play();
                state = RaceState::Finished;
                active_command = false;
                //AFFICHAGE RESULTAT
                result.setResult(1,endTime-startTime);
            }
        }
        else if(mode==2){
            float xBoat1 = boats[0].getBody()->getState().position.x/boats[0].getFactor().x;
            float xBoat2 = boats[1].getBody()->getState().position.x/boats[1].getFactor().x;
            if(xBoat1>=finishline.getPosition().x || xBoat2>=finishline.getPosition().x){
                // endingSound.play();
                state =  RaceState::Finished;
                active_command=false;
                //END TIME
                endTime = clock.getElapsedTime().asSeconds();
                //AFFICHAGE RESULTAT
                if(xBoat1 >= finishline.getPosition().x)
                    result.setResult(1,endTime-startTime);
                else
                    result.setResult(2,endTime-startTime);
            }
        }
    }
}


filesystem::path Race::getAssetPath(const std::string& relativePath){
    // __FILE__ donne le chemin du fichier source courant
    filesystem::path sourceDir = filesystem::path(__FILE__).parent_path();
    
    // Remonte jusqu’au dossier du projet (ex: depuis src/jeu.cpp → ../../assets/...)
    filesystem::path assetDir = sourceDir / ".." / "assets";

    // Normalise le chemin
    assetDir = filesystem::canonical(assetDir);

    return assetDir / relativePath;
}


Race::Race(sf::RenderWindow& wd, sf::Clock & clk):window(wd), startingLights(clk){
    clock = clk;
    dt = 0.01;

    // Création des ligne départ/arrivée
    startline = Line(sf::Vector2f(10.f,700.f), sf::Vector2f(120.f,40.f), sf::Color::Green);
    finishline = Line(sf::Vector2f(10.f,700.f), sf::Vector2f(1150.f,10.f), sf::Color::Red);
    
    // Creation bordure
    createObstacle(sf::Vector2f(5.f,720.f),sf::Vector2f(0.f,0.f));     // bordure gauche
    createObstacle(sf::Vector2f(1280.f,5.f),sf::Vector2f(0.f,0.f));    // bordure haut 
    createObstacle(sf::Vector2f(5.f,720.f),sf::Vector2f(1275.f,0.f));  // bordure droit
    createObstacle(sf::Vector2f(1280.f,5.f),sf::Vector2f(0.f,715.f));  // bordure bas
    
    // Creation bateau
    createBoat();

    // Audio
    // endingSoundbuffer.loadFromFile(getAssetPath("audio/endrace.wav").string());
    // endingSound.setBuffer(endingSoundbuffer);
}


Race::~Race(){}


void Race::init(int m){
    startingLights.start();
    mode = m;
    clock.restart();
    if(mode==1){
        //Obstacles
        creerObstacle1();
        //Init text Joueur dashboard
        boats[0].setDashboardPlayerText(1);
    }
    else if(mode==2){
        //Obstacles
        creerObstacle2();
        //Dashboard bateau2 a  droite
        boats[1].setDashboardPosition({1000,600});

        //Text joueur
        boats[0].setDashboardPlayerText(1);
        boats[1].setDashboardPlayerText(2);

        //Placer 2e bateau a la bonne position
        boats[1].setBoatPosition({84,500});
    }
}


void Race::run(){
    sf::Int64 time_loop = 0;
    pollEvents();
    sf::Int64 begin = clock.getElapsedTime().asMicroseconds();
    update();
    render();
    sf::Int64 end = clock.getElapsedTime().asMicroseconds();
    time_loop += end - begin;
    while (time_loop >= dt*1000000){ // dt*1000000 -> 10000 microseconde -> 10 miliseconde
        engine.step(dt);
        time_loop -= dt*1000000;
    }
    window.display();
}


void Race::pollEvents(){
    if(active_command) command_control();
}


void Race::update(){
    //Update de tous les elements de la course
    //UPDATE BATEAUX
    for(Boat& b:boats){
        b.update(model);
    }
    
    //UPDATE FEU
    startingLights.update();
    updateRaceState();
}


void Race::render(){
    //Render carte et tout ce qui s'y passe
    window.clear(sf::Color::Blue);

    //DESSIN LIGNES DEPART ET ARRIVEE
    startline.draw(window);
    finishline.draw(window);

    //Obstacles
    for (const Obstacle& o:obstacles){
        o.draw(window);
    }

    //Boosts
    for(const Boost& b:boosts){
        b.draw(window);
    }

    //Bateaux
    for (Boat& b:boats){
        b.draw(window);
        collision_Ob(b);
        collision_Bo(b);
    }

    //On laise le tableau jusqu'a la fin
    if (state == RaceState::Finished)
        result.draw(window);

    //Feu
    startingLights.draw(window);
}
