#ifndef BOAT_HPP
#define BOAT_HPP

#include <SFML/Graphics.hpp>
// #include <SFML/Audio.hpp>

#include "physics/dynamicModel.h"
#include "physics/physicsEngine.h"
#include "physics/common.h"
#include "physics/platform_core.h"

#include"dashboard.hpp"

class Boat{
    private:
        sim::physics::RigidBody* body;
        sf::ConvexShape shape;
        sf::Vector2f l_point[5];
        sim::common::Vector2 factor;
        Dashboard dashboard;
        // sf::SoundBuffer engineSoundBuffer;
        // sf::Sound engineSound;

        filesystem::path getAssetPath(const std::string&);

    public:
        Boat(sim::physics::RigidBody*, sf::Color);

        sf::ConvexShape& getShape();
        sim::physics::RigidBody* getBody();
        sf::Vector2f& getPoint(int);
        sim::common::Vector2& getFactor();
        Dashboard getDashboard();
        
        void setDashboardPosition(const sf::Vector2f& pos);
        void setDashboardPlayerText(int j);
        void setBoatPosition(const sf::Vector2f& pos);

        void Move_X(sim::physics::DynamicModel, double, double, double);
        void Move_Y(sim::physics::DynamicModel, double, double, double);

        void update(sim::physics::DynamicModel);
        void update_point();
        void updateDashboard();
        sim::common::Vector2 point_rotation(const sf::Vector2f&, float) const;
        
        void draw(sf::RenderWindow &);
        
};

#endif